/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int marks;
    std::cout << "enter your marks" << std::endl;
    std::cin >> marks;
    
    if(marks>=0 && marks<=30)
    {
        std::cout << "your grade is F" << std::endl;
    }
    else if(marks>=30 && marks<=40)
    {
        std::cout << "your grade is E" << std::endl;
    }else if(marks>=40 && marks<=50)
    {
        std::cout << "your grade is D" << std::endl;
    }else if(marks>=50 && marks<=60)
    {
        std::cout << "your grade is c" << std::endl;
    }else if(marks>=60 && marks<=70)
    {
        std::cout << "your grade is B" << std::endl;
    }
    else if(marks>=70 && marks<=80)
    {
        std::cout << "your grade is B+" << std::endl;
    }
    else if(marks>=80 && marks<=90)
    {
        std::cout << "your grade is A" << std::endl;
    }else if(marks>=90 && marks<=100)
    {
        std::cout << "your grade is A+" << std::endl;
    }
    else{
        std::cout << "enter a valid value" << std::endl;

    }
    


    return 0;
}