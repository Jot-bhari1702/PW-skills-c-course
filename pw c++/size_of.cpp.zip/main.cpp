/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
   int integer  = sizeof(int) ;
   int character = sizeof(char);
   int boolean = sizeof(bool);
   int decimal = sizeof(float);
   int double_f = sizeof(double);
   int longint = sizeof(long);
   
   
   std::cout << "the size of datatypes in bytes is " << std::endl;
   
   std::cout << "the size of (int)" << integer << "bytes"<<std::endl;
   std::cout << "the size of (char)" << character << "bytes"<< std::endl;
   std::cout << "the size of (bool)" <<boolean << "bytes"<< std::endl;
   std::cout << "the size of (float)" << decimal << "bytes"<< std::endl;
   std::cout << "the size of (double)" << double_f << "bytes"<< std::endl;
   std::cout << "the size of (long)" << longint << "bytes"<<std::endl;
   

    return 0;
}