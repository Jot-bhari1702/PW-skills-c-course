/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int
main ()
{
  int num1;
  int num2;

  std::cout << "enter the first numbers you want to compare" << std::endl;

  std::cin >> num1;

  std::cin >> num2;

  num1 ==
    num2 ? std::cout << "the numbers are equal" << std::endl : std::
    cout << "the numbers are not equal" << std::endl;




  return 0;
}
