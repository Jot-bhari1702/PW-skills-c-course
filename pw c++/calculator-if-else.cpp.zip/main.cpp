/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    double num1,num2,result;
    char opera;
    std::cin >> num1>>opera>>num2;
   
       
    if(opera== '+')
    {
        result = num1+num2;
        std::cout << result << std::endl;
        
    }
else if(opera=='-')
    {
        result = num1-num2;
        std::cout << result << std::endl;
        
    }
    else if(opera=='*')
    {
        result = num1*num2;
        std::cout << result << std::endl;
        
    }else if(opera=='/')
    {
        result = num1/num2;
        std::cout << result << std::endl;
        
    }
    
    return 0;
}