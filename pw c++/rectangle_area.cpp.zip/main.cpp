/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int
main ()
{
  float length;
  float breadth;
  float area;

  std::cout << "enter the length and breadth of the rectangle " << std::endl;
  std::cin >> length;
  std::cin >> breadth;

  area = length * breadth;

  std::
    cout << "the area of the rectangle with length " << length <<
    "and breadth" << breadth << "is " << area << std::endl;
  return 0;
}
