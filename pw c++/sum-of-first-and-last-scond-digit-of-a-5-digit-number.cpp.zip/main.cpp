/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int
main ()
{
  int num, first, second, third, fourth, fifth, sum;

  std::cout << " enter the number" << std::endl;
  
  cin>>num;

  first = num / 10000;
  num = num % 10000;

  second = num / 1000;
  num = num % 1000;

  third = num / 100;

  num = num % 100;

  fourth = num / 10;
  num = num % 10;

  fifth = num;

  sum = first + fourth;


  std::cout << "the sum is " << sum << std::endl;

  return 0;
}
