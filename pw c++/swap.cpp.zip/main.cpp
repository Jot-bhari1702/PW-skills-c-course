/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int
main ()
{
  int a;
  int b;
  std::cin >> a;
  std::cin >> b;
  std::cout << "the value of a is " << a << std::endl;
  std::cout << "the value of b is " << b << std::endl;
  int c;
  c = a;
  a = b;
  b = c;


  std::
    cout << "the value of a and b is" << a << " and" << b << " respectively"
    << std::endl;

  return 0;
}
