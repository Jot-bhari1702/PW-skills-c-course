/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    char opera ;
    int num1,num2;
    std::cout << "enter the two numbers" << std::endl;
    std::cin >> num1;
    std::cin >> num2;
    
    std::cout << " enter the operator" << std::endl;
    
    std::cin >> opera;
    
    switch(opera)
    {
        case '+' :
        std::cout << "the sum is " <<num1+num2<< std::endl;
        break;
         case '-' :
        std::cout << "the substraction is " <<num1-num2<< std::endl;
        break;
         case '*':
        std::cout << "the multiplication is " <<num1*num2<< std::endl;
        break;
         case '/' :
        std::cout << "the division  is " <<num1/num2<< std::endl;
        break;
        
        default:
        std::cout << "enter a valid operator" << std::endl;
        
    }

    return 0;
}