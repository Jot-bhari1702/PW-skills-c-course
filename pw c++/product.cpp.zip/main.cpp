#include<iostream>
using namespace std;
int main()
{
    
    int num1;
    int num2;
    
    std::cout << "enter the first number " << std::endl;
    cin >> num1;
    std::cout << "enter the second number " << std::endl;
    cin >>num2;
    
    int product = num1*num2;
    
    std::cout << "the product of the numbers entered is "<< product  << std::endl;
    
    return 0;
}