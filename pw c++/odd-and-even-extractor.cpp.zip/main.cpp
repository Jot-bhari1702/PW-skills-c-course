/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int i, min, max;
    
    std::cout << "enter the minimum value " << std::endl;
    std::cin >> min;
    std::cout << "enter the maximum value" << std::endl;
    std::cin >> max;
    std::cout << "the odd and even numbers between 1 and 50 are " << std::endl;
    for (int i = min; i <= max; i++) {
        
        if(i%2==0)
        {
            std::cout << i<<"is even" << std::endl;
        }
        
        else
        {
            std::cout << i<<" is odd" << std::endl;
        }
    }

    return 0;
}